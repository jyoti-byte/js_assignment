var myName = prompt("Enter your name");

console.log(typeof(myName));
