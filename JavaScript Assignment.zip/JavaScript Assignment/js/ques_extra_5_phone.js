var phoneNumber = '9843472974';

console.log(phoneNumber);