let favColor;
let favBook;
let favFilm;
let favSeries;
let favFruit;

console.log(favColor);
console.log(favBook);
console.log(favFilm);
console.log(favSeries);
console.log(favFruit);

var num1;
var num2;
var num3;
var num4;
var num5;

console.log(num1);
console.log(num2);
console.log(num3);
console.log(num4);
console.log(num5);