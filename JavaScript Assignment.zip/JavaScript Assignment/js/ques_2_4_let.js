let num1 , num2;
num1 = true, num2 = true;

console.log(num1 + num2);


//no error occurs, we ca do multiple declarations on the same line
//true means 1 so 1 +  1 equals 2