let firstName = prompt("Enter your first name");
let lastName  = prompt("Enter your last name");
console.log(firstName + ' ' + lastName);