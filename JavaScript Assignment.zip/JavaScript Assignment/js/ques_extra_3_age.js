var age = 26;

console.log(age);