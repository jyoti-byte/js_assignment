//dynamically typed languages

//In simple words, dynamically typed language means the type of variables 
//is checked during the run-time, even the code is dynamic.
//JS is called a dynamically typed language because the type of variable
// is not defined during the declaration. Also same variable can be used 
//to store the different data types as number, string, object, Boolean and so on.
