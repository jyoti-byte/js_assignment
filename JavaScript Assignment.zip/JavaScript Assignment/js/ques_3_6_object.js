const email = {
    sentTo   : "ITSNP",
    sentFrom : "Jyoti",
    send     : function () {
        console.log("Message sent");
    }    
};
//console.log(email);
email.send();