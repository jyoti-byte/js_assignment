const laptop = {
    model  : "Inspiron 5559",
    brand  : "Dell",
    os     : "Windows",
    price  : "40000",
    type   : "x64-based PC",
    ram    : "8gb"
};

//console.log(laptop);