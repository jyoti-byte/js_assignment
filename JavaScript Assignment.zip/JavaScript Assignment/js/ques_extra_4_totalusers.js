var totalUsers  = null;

 console.log(totalUsers);