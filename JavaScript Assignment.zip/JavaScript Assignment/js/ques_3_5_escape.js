let text = "Ram said,\"Programming is a fun game.\""
console.log(text);