let num = '20';

console.log(-num + 1);