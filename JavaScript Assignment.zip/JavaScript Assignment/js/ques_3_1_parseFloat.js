let num = prompt("Enter the number");

num     = parseFloat(num);

console.log(num);
