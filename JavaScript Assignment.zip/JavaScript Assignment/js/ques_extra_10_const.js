const car;

car = "Ferrari";

console.log(car);
//it throws an error coz constant should be assigned
//at the time of declaration
