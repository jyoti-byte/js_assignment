//lower camelCase
var myFavNovel   = "The Half Girlfriend";

var MyFavNovel   = "The Three Mistakes of my Life";

var My_Fav_Novel = "Girl in Room 105";

//console.log(myFavNovel);
//console.log(MyFavNovel);
console.log(My_Fav_Novel);
