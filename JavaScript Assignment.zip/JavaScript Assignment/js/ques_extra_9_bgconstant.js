const BG_COLOR = "red";

//console.log(BG_COLOR);