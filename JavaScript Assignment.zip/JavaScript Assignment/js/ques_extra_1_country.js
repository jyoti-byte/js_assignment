var city = "Kathmandu";
