var myName;
myName = "Jyoti Chaudhary";
console.log(myName);
alert(myName);
