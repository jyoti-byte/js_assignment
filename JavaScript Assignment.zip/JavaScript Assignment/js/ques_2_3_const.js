const animalName = "Dog";
//const animalName = "Cat";
//we cannot declare two constants with the same name

console.log(animalName);