let number = '999';

console.log(+number + 1);