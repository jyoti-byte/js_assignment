const fruit = {
    name       : "Apple",
    price      :  200,
    healthy    : true,
    production : undefined,
    extra      : {
        color  : 'red',
        weight : 150,
        liked  : true
    }
};

console.log(typeof(fruit.name));
console.log(typeof(fruit.price));
console.log(typeof(fruit.healthy));
console.log(typeof(fruit.production));
console.log(typeof(fruit.extra));
